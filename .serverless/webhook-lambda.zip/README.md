# misc-eha-automations
Automated workflow  that triggers for all organizational actions

This GitHub Action listens for the create event with the repository type and adds the "All" team to the new repository using a curl command and the GitHub API. 
